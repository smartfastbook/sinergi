<?php
function rupiah($nilai, $pecahan = 0) {
    return number_format($nilai, $pecahan, ',', ',');
}
?>
<div class="table-responsive">
       <hr>
	   
	   <table id="example2" class="table table-striped" style="width:100%">
        <thead class="bg-primary text-white">
            <tr>
                <th>Aksi</th>
				<th>No</th>
                <th>Kode Barang</th>
				<th>Nama Barang</th>
                <th>QTY</th>
                <th>Harga Bandrol</th>
                <th>Diskon %</th>
				<th>Diskon Rp</th>
				<th>Harga Diskon</th>
				<th>Total</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$no=1;
		$jumlah=0;
		$jqty=0;
		foreach($q as $h){
		$jumlah+=$h->total;
		$jqty+=$h->qty;
		?>
            <tr>
                <td><button onclick="Delete(<?=$h->noid?>)" class="btn btn-danger btn-sm">X</button></td>
				<td><?=$no++?></td>
                <td><?=$h->kode?></td>
                <td><?=$h->nama?></td>
                <td><?=rupiah($h->qty)?></td>
				<td><?=rupiah($h->harga)?></td>
                <td><?=rupiah($h->diskon_pct)?></td>
                <td><?=rupiah($h->diskon_nilai)?></td>
                <td><?=rupiah($h->harga_diskon)?></td>
                <td><?=rupiah($h->total)?></td>
				</tr>
		<?php } ?>
		
        </tbody>
        <tfoot>
            <tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>SUB TOTAL</th>
				<th>
				<input type="number" id="jumlah" hidden class="form-control" value="<?=$jqty?>">
				<input type="number" id="subtotal" readonly class="form-control" value="<?=$jumlah?>"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>DISKON RUPIAH</th>
				<th><input type="number" id="diskon" onkeyup="Bayar()" value="0" class="form-control"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>ONGKIR</th>
				<th><input type="number" id="ongkir" onkeyup="Bayar()" value="0" class="form-control"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>TOTAL BAYAR</th>
				<th><input type="number" id="bayar" readonly value="<?=$jumlah?>" class="form-control"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> <a href="<?=base_url('Transaksi/hapus')?>" class="btn btn-sm btn-danger">BATALKAN</button></th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th></th>
				<th><button onclick="Simpan()" class="btn btn-sm btn-success">SIMPAN</button></th>
            </tr>
        </tfoot>
    </table>
	
</div>

