<main id="main" class="main">
<form><button type="submit" class="btn btn-lg btn-primary float-sm-end"><i class="bi bi-arrow-repeat"></i></button></form>
    <div class="row pagetitle">
	
      <h1>Data Registrasi</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Pages</li>
          <li class="breadcrumb-item active">Register</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section" style="margin-top:-25px;">
      <div class="row bg-white" style="padding:5px;">
	  <div class="table-responsive">
       <table id="example" class="table table-striped" style="width:100%">
        <thead class="bg-primary text-white">
            <tr>
                <th>No</th>
                <th>Kode & Tanggal</th>
				<th>Keterangan</th>
                <th>Tipe/Info</th>
                <th>Info Bayar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$no=1;
		foreach($q as $h){
		?>
            <tr>
                <td><?=$no++?></td>
                <td><?=$h->regcode?><br><?=$h->regtime?></td>
                <td>CORP : <?=$h->snama?><br>PER : <?=$h->regperiode?> <?=$h->regpaket?><br>BYR :<?=rupiah($h->regtotal)?></td>
                <td><?=$h->regmail?><br><?=str_replace('|','<br>',$h->reginfo)?></td>
                <td><h4><?=$h->regstatus?></h4></td>
                <td>
				<span <?php if($h->regstatus=='PAID') {echo 'hidden';}?>>
				<button type="button" class="btn btn-sm btn-success" onclick="Setid('APPROVE','<?=$h->regid?>','<?=$h->regcode?>','<?=md5('SFB'.$h->regid.$h->regcode)?>','Silahkan Masukan Info Pembayaran :')" data-bs-toggle="modal" data-bs-target="#exampleModal">
 <i class="bi bi-clipboard2-check"></i> Aprove
</button>

<button type="button" class="btn btn-sm btn-danger" onclick="Setid('TOLAK','<?=$h->regid?>','<?=$h->regcode?>','<?=md5('SFB'.$h->regid.$h->regcode)?>','Silahkan Masukan Alasan Penolakan :')" data-bs-toggle="modal" data-bs-target="#exampleModal">
 <i class="bi bi-clipboard-x-fill"></i> Tolak
</button>
</span>
				</td>
            </tr>
		<?php } ?>
		
        </tbody>
        <tfoot class="bg-primary text-white">
            <tr>
                <th colspan="6">Approve : <?=$paid?> | Menunggu : <?=$unpaid?> | Tolak : <?=$tolak?>  </th>
            </tr>
        </tfoot>
    </table>
</div>
       </div>
    </section>

  </main><!-- End #main -->
  
  <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" action="Register/Proses" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><span id="tform"></span> REGISTRASI</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="text" id="aksi" name="aksi" hidden>
		<input type="text" id="regid" name="id" hidden>
		<input type="text" id="code" name="code" hidden>
		<input type="text" id="encode" name="encode" hidden>
		<span id="tdir">Silahkan Masukan Info Bayar</span>
		<textarea class="form-control" name="ket" rows="4"></textarea>
		Reg id <span id="tcode"></span> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Proses</button>
      </div>
    </form>
  </div>
</div>

<script>
function Setid(aksi,id,code,encode,tdir)
{
	document.getElementById("aksi").value = aksi;
	document.getElementById("regid").value = id;
	document.getElementById("code").value = code;
	document.getElementById("encode").value = encode;
	document.getElementById("tcode").innerHTML = code;
	document.getElementById("tdir").innerHTML = tdir;
	document.getElementById("tform").innerHTML = aksi;
}
</script>