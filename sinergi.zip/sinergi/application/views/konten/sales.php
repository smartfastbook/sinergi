<main id="main" class="main">
<a href="<?=base_url('Transaksi')?>" class="btn  btn-primary float-sm-end">INPUT PENJUALAN</a>
    <div class="row pagetitle">
      <h1>Data Penjualan</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Pages</li>
          <li class="breadcrumb-item active">Penjualan</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section" style="margin-top:-25px;">
      <div class="bg-white" style="padding:10px;">
	  
	  

	  <div class="table-responsive">
       
	   <table id="example" class="table table-striped" style="width:100%">
        <thead class="bg-primary text-white">
            <tr>
                <th>No</th>
                <th>No Transaksi</th>
				<th>Tanggal</th>
                <th>Nama Customer</th>
                <th>Jumlah Barang</th>
                <th>Sub Total</th>
				<th>Diskon</th>
				<th>Ogkir</th>
				<th>Total</th>
				<th>Detail</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$no=1;
		foreach($q as $h){
		?>
            <tr>
                <td><?=$no++?></td>
                <td><?=$h->kode?></td>
                <td><?=$h->tgl?></td>
                <td><?=$h->name?></td>
                <td><?=rupiah($h->jumlah)?></td>
                <td><?=rupiah($h->subtotal)?></td>
                <td><?=rupiah($h->diskon)?></td>
                <td><?=rupiah($h->ongkir)?></td>
                <td><?=rupiah($h->total_bayar)?></td>
				<td><a href="<?=base_url('Detail?id=')?><?=$h->sid?>" class="btn btn-info"><span class="bi bi-search"></span></a></td>
				</tr>
		<?php } ?>
		
        </tbody>
        <tfoot class="bg-primary text-white">
            <tr>
                <th>No</th>
				<th>No Transaksi</th>
				<th>Tanggal</th>
                <th>Nama Customer</th>
                <th>Jumlah Barang</th>
                <th>Sub Total</th>
				<th>Diskon</th>
				<th>Ogkir</th>
				<th>Total</th>
            </tr>
        </tfoot>
    </table>
</div>
       </div>
    </section>

  </main><!-- End #main -->