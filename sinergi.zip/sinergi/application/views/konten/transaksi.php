<main id="main" class="main">

    

    <section class="section" style="margin-top:-25px;">
	<hr>
      <div class="row bg-white" style="padding:10px;">
	  
	   <div class="col-sm-4">
	  NO FAKTUR<input type="text" id="faktur" value="<?=date('ymdHis')?>" class="form-control">
	  TANGGAL<input id="tgl" type="date" value="<?=date('Y-m-d')?>" class="form-control">
	  PILIH CUSTOMER
	  <select onchange="SetHp()" name="cust" id="cust" class="form-control">
	  <option value="|">PILIH CUSTOMER</option>
	  <?php foreach ($cus as $c) {?>
	  <option value="<?=$c->id?>|<?=$c->telp?>"><?=$c->name?></option>
	  <?php }?>
	  </select>
	  NO HP<input id="nohp" type="number" readonly class="form-control">
	  </div>
	  <div class="col-sm-4">
	  PILIH BARANG
	  <select onchange="SetBrg()" name="brg" id="brg" class="form-control">
	  <option value="|">PILIH BARANG</option>
	  <?php foreach ($brg as $b) {?>
	  <option value="<?=$b->id?>|<?=$b->harga?>"><?=$b->nama?></option>
	  <?php }?>
	  </select>
	  QTY<input type="number" onkeyup="SetBrg()" value='0' id="qty" class="form-control">
	  HARGA<input id="hrg" type="number" value='0' readonly class="form-control">
	  <div class="row">
	  <div class="col-sm-6">
	  DISKON %<input type="number" onkeyup="SetBrg()" id="disp" value="0" class="form-control">
	  </div>
	  <div class="col-sm-6">
	  DISKON Rp.<input type="number" id="disr" value="0" readonly class="form-control">
	  </div>
	  </div>
	  </div>
	  <div class="col-sm-4">
	  HARGA SETELAH DISKON<input id="hrgdis" type="number" readonly value="0" class="form-control">
	  TOTAL<input id="total" type="number" value="0"  readonly class="form-control">
	  <hr>
	  <p align="right">
	  <button onclick="Process()" class="btn btn-primary">PROSES</button>
	  </p>
	  </div>
<span id="listtrx">
	  <div class="table-responsive">
       <hr>
	   
	   <table id="example2" class="table table-striped" style="width:100%">
        <thead class="bg-primary text-white">
            <tr>
                <th>Aksi</th>
				<th>No</th>
                <th>Kode Barang</th>
				<th>Nama Barang</th>
                <th>QTY</th>
                <th>Harga Bandrol</th>
                <th>Diskon %</th>
				<th>Diskon Rp</th>
				<th>Harga Diskon</th>
				<th>Total</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$no=1;
		$jumlah=0;
		$jqty=0;
		foreach($q as $h){
		$jumlah+=$h->total;
		$jqty+=$h->qty;
		?>
            <tr>
                <td><button onclick="Delete(<?=$h->noid?>)" class="btn btn-danger btn-sm">X</button></td>
				<td><?=$no++?></td>
                <td><?=$h->kode?></td>
                <td><?=$h->nama?></td>
                <td><?=rupiah($h->qty)?></td>
				<td><?=rupiah($h->harga)?></td>
                <td><?=rupiah($h->diskon_pct)?></td>
                <td><?=rupiah($h->diskon_nilai)?></td>
                <td><?=rupiah($h->harga_diskon)?></td>
                <td><?=rupiah($h->total)?></td>
				</tr>
		<?php } ?>
		
        </tbody>
        <tfoot>
            <tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>SUB TOTAL</th>
				<th>
				<input type="number" id="jumlah" hidden class="form-control" value="<?=$jqty?>">
				<input type="number" id="subtotal" readonly class="form-control" value="<?=$jumlah?>"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>DISKON RUPIAH</th>
				<th><input type="number" id="diskon" onkeyup="Bayar()" value="0" class="form-control"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>ONGKIR</th>
				<th><input type="number" id="ongkir" onkeyup="Bayar()" value="0" class="form-control"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> </th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th>TOTAL BAYAR</th>
				<th><input type="number" id="bayar" readonly value="<?=$jumlah?>" class="form-control"></th>
            </tr>
			<tr>
                <th></th>
				<th></th>
                <th> <a href="<?=base_url('Transaksi/hapus')?>" class="btn btn-sm btn-danger">BATALKAN</button></th>
				<th> </th>
                <th></th>
                <th> </th>
                <th> </th>
				<th> </th>
				<th></th>
				<th><button onclick="Simpan()" class="btn btn-sm btn-success">SIMPAN</button></th>
            </tr>
        </tfoot>
    </table>
	
</div>
</span>
       </div>
    </section>

  </main><!-- End #main -->
  
  <script>
  function SetHp(){
  var cust = document.getElementById("cust").value;
  var c = cust.split("|");
  document.getElementById("nohp").value = c[1];
  }
  
  function SetBrg(){
  var brg = document.getElementById("brg").value;
  var disp = document.getElementById("disp").value;
  var qty = document.getElementById("qty").value;
  
  var b = brg.split("|");
  var disr=b[1]*disp/100;
  document.getElementById("hrg").value = b[1];
  document.getElementById("disr").value=disr;
  document.getElementById("hrgdis").value=(b[1]-disr);
  document.getElementById("total").value=(b[1]-disr)*qty;
  }
  </script>
  
  
  <script>
function Process() {
var cust = document.getElementById("cust").value;
var brg = document.getElementById("brg").value;
var hrg = document.getElementById("hrg").value;
var qty = document.getElementById("qty").value;
var disp = document.getElementById("disp").value;
var disr = document.getElementById("disr").value;  
var hrgdis = document.getElementById("hrgdis").value;
var total = document.getElementById("total").value;

if (brg==null || brg=="|"){
          //alert("NOHP/IDPEL tidak boleh kosong !");
		  alert('Silahkan Pilih Barang.');
          return false;
        }; 

if (qty==null || qty==0){
          //alert("NOHP/IDPEL tidak boleh kosong !");
		  alert('Masukan QTY.');
          return false;
        }; 		
  
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("listtrx").innerHTML = this.responseText;
  }
  xhttp.open("GET", "<?=base_url()?>Transaksi/proses?cust="+cust+"&brg="+brg+"&hrg="+hrg+"&qty="+qty+"&disp="+disp+"&disr="+disr+"&hrgdis="+hrgdis+"&total="+total);
  xhttp.send();
}

function Delete(id) {
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("listtrx").innerHTML = this.responseText;
  }
  xhttp.open("GET", "<?=base_url()?>Transaksi/delete?id="+id);
  xhttp.send();
}

function Bayar() {
  var subtotal = parseInt(document.getElementById("subtotal").value);
  var diskon = parseInt(document.getElementById("diskon").value);
  var ongkir = parseInt(document.getElementById("ongkir").value);
  var bayar = subtotal+ongkir-diskon;
  document.getElementById("bayar").value=bayar;
}



function Simpan() {
var faktur = document.getElementById("faktur").value;
var cust = document.getElementById("cust").value;
var tgl = document.getElementById("tgl").value;
var diskon = document.getElementById("diskon").value;
var ongkir = document.getElementById("ongkir").value;
var bayar = document.getElementById("bayar").value;
var subtotal = document.getElementById("subtotal").value;
var jumlah = document.getElementById("jumlah").value;  

if (cust==null || cust=="|"){
          //alert("NOHP/IDPEL tidak boleh kosong !");
		  alert('Silahkan Pilih Customer.');
          return false;
        }; 

if (bayar==null || bayar==0){
          //alert("NOHP/IDPEL tidak boleh kosong !");
		  alert('Masukan Produk.');
          return false;
        }; 		
  
  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    document.getElementById("listtrx").innerHTML = this.responseText;
	alert('Data Berhasil Disimpan.');
	window.location = "<?=base_url('Penjualan')?>";
  }
  xhttp.open("GET", "<?=base_url()?>Transaksi/simpan?cust="+cust+"&tgl="+tgl+"&subtotal="+subtotal+"&faktur="+faktur+"&diskon="+diskon+"&ongkir="+ongkir+"&bayar="+bayar+"&jumlah="+jumlah);
  xhttp.send();
}
</script>
  
  
  <script>
  $("input.number").on("keydown", function (e) {
    // allow function keys and decimal separators
    if (
        // backspace, delete, tab, escape, enter, comma and .
        $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 188, 190]) !== -1 ||
        // Ctrl/cmd+A, Ctrl/cmd+C, Ctrl/cmd+X
        ($.inArray(e.keyCode, [65, 67, 88]) !== -1 && (e.ctrlKey === true || e.metaKey === true)) ||
        // home, end, left, right
        (e.keyCode >= 35 && e.keyCode <= 39)) {
 
        /*
        // optional: replace commas with dots in real-time (for en-US locals)
        if (e.keyCode === 188) {
            e.preventDefault();
            $(this).val($(this).val() + ".");
        }
 
        // optional: replace decimal points (num pad) and dots with commas in real-time (for EU locals)
        if (e.keyCode === 110 || e.keyCode === 190) {
            e.preventDefault();
            $(this).val($(this).val() + ",");
        }
        */
 
        return;
    }
    // block any non-number
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
        e.preventDefault();
    }
});
</script>