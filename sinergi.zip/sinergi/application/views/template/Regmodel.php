<?php

class Regmodel extends CI_Model
{
	public function cari($status)
  {
    $h=$this->db->get_where('setting',array('regstatus'=>$status))->num_rows();
	return $h;
  }
}