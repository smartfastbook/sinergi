<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Detail extends CI_Controller {
	
	function __construct()
    {
        parent::__construct();
header("Access-Control-Allow-Origin:*");
date_default_timezone_set ('Asia/Jakarta');
set_time_limit(0);
//error_reporting(0);

    }
	
	public function index()
	{
$var['judul']='PENJUALAN';
$var['m1']='jual';

$id=$_GET['id'];

$this->db->select('*');
$this->db->select('sales.kode as faktur');
$this->db->from('sales');
$this->db->join('customer', 'customer.id = sales.cust_id');
$this->db->where('sales.id',$id);
$data['s']=$this->db->get()->row_array();

$this->db->select('*');
$this->db->from('sales_det');
$this->db->where('sales_id',$id);
$this->db->join('barang', 'barang.id = sales_det.barang_id');
$data['q']=$this->db->get()->result();


	
	
$this->load->view('template/header',$var);
$this->load->view('konten/detail',$data);
$this->load->view('template/footer');
	}
	
	
	
	
	
	

}
