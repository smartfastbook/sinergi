<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Transaksi extends CI_Controller {
	
	function __construct()
    {
        parent::__construct();
header("Access-Control-Allow-Origin:*");
date_default_timezone_set ('Asia/Jakarta');
set_time_limit(0);
//error_reporting(0);

    }
	
	public function index()
	{
$var['judul']='TRANSAKSI';
$var['m1']='trx';

$data['cus']=$this->db->get('customer')->result();
$data['brg']=$this->db->get('barang')->result();

$this->db->select('*');
$this->db->from('sales_temp');
$this->db->join('barang', 'barang.id = sales_temp.barang');
$data['q']=$this->db->get()->result();
	
$this->load->view('template/header',$var);
$this->load->view('konten/transaksi',$data);
$this->load->view('template/footer');
	}
	
	public function proses()
	{
/*
Transaksi/proses?cust="+cust+"&brg="+brg+"&hrg="+hrg+"&qty="+qty+"&disp="+disp+"&disr="+disr+"&hrgdis="+hrgdis+"&total="+total
*/
$cust=$_GET['cust'];
$brg=$_GET['brg'];
$b=explode('|',$brg);
$hrg=$_GET['hrg'];
$qty=$_GET['qty'];
$disp=$_GET['disp'];
$disr=$_GET['disr'];
$hrgdis=$_GET['hrgdis'];
$total=$_GET['total'];

$data=array(
'barang'=>$b[0],
'harga'=>$hrg,
'qty'=>$qty,
'diskon_pct'=>$disp,
'diskon_nilai'=>$disr,
'harga_diskon'=>$hrgdis,
'total'=>$total
);
$this->db->insert('sales_temp',$data);

$this->db->select('*');
$this->db->from('sales_temp');
$this->db->join('barang', 'barang.id = sales_temp.barang');
$data['q']=$this->db->get()->result();
$this->load->view('sales_temp',$data);
	
	}
	
	public function delete()
	{
/*
Transaksi/proses?cust="+cust+"&brg="+brg+"&hrg="+hrg+"&qty="+qty+"&disp="+disp+"&disr="+disr+"&hrgdis="+hrgdis+"&total="+total
*/
$id=$_GET['id'];
$this->db->where('noid',$id);
$this->db->delete('sales_temp');

$this->db->select('*');
$this->db->from('sales_temp');
$this->db->join('barang', 'barang.id = sales_temp.barang');
$data['q']=$this->db->get()->result();
$this->load->view('sales_temp',$data);
	
	}
	

public function simpan()
	{
/*
simpan?cust="+cust+"&tgl="+tgl+"&subtotal="+subtotal+"&faktur="+faktur+"&diskon="+diskon+"&ongkir="+ongkir+"&bayar="+bayar
*/
$cust=$_GET['cust'];
$c=explode('|',$cust);
$tgl=$_GET['tgl'];
$faktur=$_GET['faktur'];
$subtotal=$_GET['subtotal'];
$diskon=$_GET['diskon'];
$ongkir=$_GET['ongkir'];
$bayar=$_GET['bayar'];
$jumlah=$_GET['jumlah'];

$data=array(
'kode'=>$faktur,
'tgl'=>$tgl,
'cust_id'=>$c[0],
'jumlah'=>$jumlah,
'subtotal'=>$subtotal,
'diskon'=>$diskon,
'ongkir'=>$ongkir,
'total_bayar'=>$bayar
);
$this->db->insert('sales',$data);
$id=$this->db->insert_id();

$q=$this->db->get('sales_temp')->result();
foreach ($q as $h){
$di=array(
'sales_id'=>$id,
'barang_id'=>$h->barang,
'harga_bandrol'=>$h->harga,
'qty'=>$h->qty,
'diskon_pct'=>$h->diskon_pct,
'diskon_nilai'=>$h->diskon_nilai,
'harga_diskon'=>$h->harga_diskon,
'total'=>$h->total
);
$this->db->insert('sales_det',$di);	
}
	
$this->db->where(array('noid>'=>0));
$this->db->delete('sales_temp');

echo 'ok';

	}


public function hapus()
{
$this->db->where(array('noid>'=>0));
$this->db->delete('sales_temp');	
redirect(base_url('Penjualan'));	
}
}
