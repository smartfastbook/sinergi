<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Penjualan extends CI_Controller {
	
	function __construct()
    {
        parent::__construct();
header("Access-Control-Allow-Origin:*");
date_default_timezone_set ('Asia/Jakarta');
set_time_limit(0);
//error_reporting(0);

    }
	
	public function index()
	{
$var['judul']='PENJUALAN';
$var['m1']='jual';

$this->db->select('*');
$this->db->select('sales.id as sid');
$this->db->from('sales');
$this->db->join('customer', 'customer.id = sales.cust_id');
$data['q']=$this->db->get()->result();


	
	
$this->load->view('template/header',$var);
$this->load->view('konten/sales',$data);
$this->load->view('template/footer');
	}
	
	
	
	
	
	

}
